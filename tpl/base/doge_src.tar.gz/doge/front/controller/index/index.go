package index

import (
	"main/controller/base"

	"github.com/gin-gonic/gin"
)

type indexCtl struct {
}

var IndexCtl = indexCtl{}

func (p *indexCtl) Index(c *gin.Context) {

	c.HTML(base.HTTP_OK, "index_index.html", gin.H{
		"title": "站点首页",
	})
}
