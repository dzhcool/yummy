package common

/**
 * 公共接口
 */
import (
	"common/modules/setting"
	log "common/modules/zapkit"
	"html"
	"main/controller/base"
	"strings"

	"github.com/gin-gonic/gin"
)

type ueditorController struct{}

var UeditorController = ueditorController{}

func (uc *ueditorController) Controller(c *gin.Context) {
	action := strings.ToLower(c.Query("action"))
	log.Debugf("action:%s", action)

	switch action {
	case "config":
		uc.GetConfig(c)
	case "uploadimage":
		uc.UploadImage(c)
	default:
		uc.Return(c, map[string]string{"state": "请求地址出错"})
	}
	return
}

// ueditor 编辑器初始化
type UeditorConfigType struct {
	ImageUrl        string   `json:"imageUrl"`
	ImageUrlPrefix  string   `json:"imageUrlPrefix"`
	ImagePath       string   `json:"imagePath"`
	ImageFieldName  string   `json:"imageFieldName"`
	ImageMaxSize    int      `json:"imageMaxSize"`
	ImageAllowFiles []string `json:"imageAllowFiles"`
	// 额外测试参数
	ImageActionName     string `json:"imageActionName"`
	ImageCompressBorder int    `json:"imageCompressBorder"`
	ImageCompressEnable bool   `json:"imageCompressEnable"`
	ImageInsertAlign    string `json:"imageInsertAlign"`
	ImagePathFormat     string `json:"imagePathFormat"`
}

func (uc *ueditorController) GetConfig(c *gin.Context) {

	config := new(UeditorConfigType)
	config.ImageUrl = "/ueditor/controller?action=uploadimage"
	config.ImageUrlPrefix = setting.Config.MustString("upload.baseUri", "")
	config.ImagePath = ""
	config.ImageFieldName = "upfile"
	config.ImageMaxSize = 8 * 1024 * 1024
	allow := []string{".png", ".jpg", ".jpeg"}
	config.ImageAllowFiles = allow
	// 额外
	config.ImageActionName = "uploadimage"
	config.ImageCompressBorder = 1600
	config.ImageCompressEnable = true
	config.ImageInsertAlign = "none"
	config.ImagePathFormat = "{yyyy}{mmdd}/{time}{rand:6}"

	uc.Return(c, config)
}

func (uc *ueditorController) UploadImage(c *gin.Context) {
	ret := make(map[string]interface{})
	file, url, err := base.UploadFile("ueditor", "upfile", c, "image")
	log.Debugf("file:%s, url:%s, err:%v", file, url, err)
	if err != nil {
		ret["state"] = "ERROR"
		uc.Return(c, ret)
		return
	}
	// idx := len("/storage/upload/")
	// uploadURI := file[idx:]
	// obj, _ := nurl.ParseRequestURI(url)

	ret["state"] = "SUCCESS"
	ret["url"] = url
	ret["file"] = file
	ret["title"] = ""
	ret["original"] = ""

	uc.Return(c, ret)
}

func (uc *ueditorController) Return(c *gin.Context, ret interface{}) {
	callback := html.EscapeString(c.Query("callback"))

	if len(callback) > 0 {
		c.JSONP(200, ret)
	} else {
		c.JSON(200, ret)
	}
}
