package common

import (
	"main/controller/base"

	"github.com/gin-gonic/gin"
)

// 页面跳转提示
func Tips(c *gin.Context, msg, url string) {
	c.HTML(base.HTTP_OK, "tips.html", gin.H{
		"title": "页面跳转中",
		"msg":   msg,
		"url":   url,
		"type":  0,
	})
}
func JumpUrl(c *gin.Context) {
	msg := c.Query("msg")
	url := c.Query("url")

	c.HTML(base.HTTP_OK, "tips.html", gin.H{
		"title": "页面跳转中",
		"msg":   msg,
		"url":   url,
		"type":  0,
	})
}
