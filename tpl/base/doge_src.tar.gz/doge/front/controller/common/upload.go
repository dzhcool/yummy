package common

import (
	"common/modules/picture"
	"common/utils"
	"main/controller/base"

	"github.com/gin-gonic/gin"
)

// 通用图片上传
func UploadImage(c *gin.Context) {
	biz := c.PostForm("biz")
	extpath := c.PostForm("extpath")
	filename := c.PostForm("name")

	if len(biz) <= 0 {
		biz = "default"
	}

	file, url, err := base.UploadFile(biz, "image", c, extpath)
	if err != nil {
		c.JSON(base.HTTP_OK, gin.H{
			"errno":  1,
			"errmsg": err.Error(),
			"data":   nil,
		})
		return
	}
	// 排查图片压缩
	if biz == "site" {
		picture.Thumb(file, 800, 800)
	}
	c.JSON(base.HTTP_OK, gin.H{
		"errno":  0,
		"errmsg": err,
		"data": gin.H{
			"file":     file,
			"url":      url,
			"filename": filename,
			"md5":      utils.MD5(filename),
		},
	})
}
