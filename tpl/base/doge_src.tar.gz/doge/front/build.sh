#!/bin/sh
# 项目启动脚本
# @date 2017-10-23
# @version 1.0

USER=${USER/-/_}
PRJ_ROOT=$(cd `dirname $0`; pwd)
PRJ_NAME=`basename ${PRJ_ROOT}`

ENV=$2
if [ "${ENV}" == "" ];then
    ENV="dev"
fi
BIN_NAME="doge" # 生成二进制文件文件名，也是docker镜像名称
BIN=${PRJ_ROOT}/bin/${BIN_NAME} # 生成二进制文件路径
BIN_DOCKER="docker " # docker二进制文件路径
HUB="registry.cn-shanghai.aliyuncs.com/dzhcool"  # 镜像hub地址

echo "-------------------- ${BIN_NAME} --------------------"
# 编译节点注入变量
buildTime=`date +'%Y-%m-%d %H:%M:%S'`
buildVersion=
buildGoVersion=`go version`
LDFlags=" \
    -X 'common/modules/buildinfo.build_time=${buildTime}' \
    -X 'common/modules/buildinfo.build_version=' \
    -X 'common/modules/buildinfo.build_go_version=${buildGoVersion}' \
"

export PATH=.:/sbin:/usr/sbin:/usr/local/sbin:/usr/local/bin:/bin:/usr/bin:/usr/local/bin

# 本地调试直接run
function run() {
    if [ ! -f "./${BIN_NAME}" ];then
        echo "${BIN_NAME} not exists"
        exit 1
    fi

    export GP_NACOS_ENDPOINT=http://192.168.110.35:8848/
    export GP_NACOS_NAMESPACE=stream

    ./${BIN_NAME}
}

# 手动编译用
function build() {
    if [ -f "./${BIN_NAME}" ];then
        rm -f ./${BIN_NAME}
    fi

    go build -ldflags "$LDFlags" -o ${BIN_NAME} .
}

# 操作定义
function run_docker_build(){
    CGO_ENABLED=0 GOOS=linux go build -ldflags "$LDFlags" -a -installsuffix cgo -o ${BIN_NAME} .

    if [ ! -f "${BIN_NAME}" ];then
        exit 1
    fi
    mv ${BIN_NAME} conf/${BIN_NAME}

    docker_kill ${BIN_NAME}
    docker_rmi ${BIN_NAME}
    ${BIN_DOCKER} build -t ${BIN_NAME}:${ENV} conf/
    rm -f conf/${BIN_NAME}
}

# 删除docker镜像
function docker_rmi(){
    name=$1
    imageids=`${BIN_DOCKER} images|grep "${name}"|grep "${ENV}"|grep -v "grep"|awk -F ' ' '{print $3}'`
    for imageid in ${imageids}
    do
        ${BIN_DOCKER} rmi -f ${imageid}
    done
}

# 删除docker container
function docker_kill(){
    name=$1
    containerids=`${BIN_DOCKER} ps |grep "${name}"|grep "${ENV}"|grep -v "grep"|awk -F ' ' '{print $1}'`
    for containerid in ${containerids}
    do
        ${BIN_DOCKER} kill  ${containerid}
    done
}

# 推送docker镜像
function run_docker_push(){
    ${BIN_DOCKER} tag ${BIN_NAME}:$ENV ${HUB}/${BIN_NAME}:$ENV
    ${BIN_DOCKER} push ${HUB}/${BIN_NAME}:$ENV
}


case $1 in
    run)
        echo " Exec local run "
        build
        run
        exit;
        ;;
    build)
        echo " Exec local build "
        build
        exit;
        ;;
    dockerbuild)
        echo " Exec docker build "
        run_docker_build
        run_docker_push
        exit;
        ;;
    start)
        echo " Exec start "
        run
        exit;
        ;;
    *) #default
        echo " Run as: ./run.sh [run dockerbuild] [dev beta online]"
        exit;
        ;;
esac

echo "*****************End***********"

