package routers

import (
	"common/modules/setting"
	"html/template"
	"main/controller/base"
	"main/controller/index"
	"main/middleware"

	"github.com/gin-gonic/gin"
)

func Register(r *gin.Engine) {
	r.Use(middleware.Cors()) // 设置跨域header

	// 加载自定义函数
	r.SetFuncMap(template.FuncMap{
		"add":    Add,
		"strCut": StrCut,
	})

	web_inf := setting.Config.MustString("app.web_inf", "./")

	r.Static("/static", web_inf+"/static")
	r.LoadHTMLGlob(web_inf + "/templates/*.html")

	r.GET("/", index.IndexCtl.Index)

	r.GET("/favicon.ico", func(c *gin.Context) {
		c.String(200, "")
	})

	r.GET("/ie.html", base.Ie) //版本升级提示
}
