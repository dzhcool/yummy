package service

import (
	// "common/utils"

	"github.com/robfig/cron/v3"
)

type crondSvc struct {
}

func NewCrond() (*crondSvc, error) {
	ins := new(crondSvc)
	return ins, nil
}

// TODO, 注册定时任务
func (p *crondSvc) handleCommon() {
	crond := cron.New(cron.WithSeconds())
	defer crond.Start()

	// 注册定时任务
	// crond.AddFunc("1 */5 * * * *", func() {
	// 	StatSvc.stat()
	// })
}
