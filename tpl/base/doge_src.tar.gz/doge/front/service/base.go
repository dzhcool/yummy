package service

import (
	// "common/modules/setting"
	log "common/modules/zapkit"
	"context"
	"time"
)

var _baseSvc *baseSvc

type baseSvc struct {
	ctx    context.Context
	cancel context.CancelFunc
}

// 可注册service收尾工作
func closeService() {
	// TODO
}

// 可注册service init
func initService() {
	// TODO
}

func InitService() {
	_baseSvc = new(baseSvc)

	ctx, cancel := context.WithCancel(context.Background())
	_baseSvc.ctx = ctx
	_baseSvc.cancel = cancel

	initService()
	// 注册daemon
	initDaemon()
	// 注册crond
	crond, err := NewCrond()
	if err != nil {
		log.Errorf("init crond failed:%s", err.Error())
		return
	}
	crond.handleCommon()
}

func CloseService() {
	if _baseSvc != nil {
		_baseSvc.cancel()
	}
	log.Info("wait for the service to exit")

	closeService()

	time.Sleep(5 * time.Second)
	log.Info("service exited")
}

func Ctx() context.Context {
	return _baseSvc.ctx
}
