package service

import (
// "common/utils"
)

func initDaemon() {
	// go DemoSvc.Demo()
}
