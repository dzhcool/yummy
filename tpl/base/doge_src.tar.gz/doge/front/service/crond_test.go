package service

import (
	"main/test"
	"testing"
	"time"

	"github.com/robfig/cron/v3"
)

// go test -v ./service/ -test.run TestCrond
// go test -v ./service/                   // 测试全部

func init() {
	test.StubInitConfig()
	test.StubInitZapkit()
}

func (p *crondSvc) DoTest(t *testing.T) {
	p.crond = cron.New(cron.WithSeconds())
	defer p.crond.Start()

	// 注册定时任务
	p.crond.AddFunc("*/5 * * * * *", func() {
		t.Logf("%s running", time.Now().Format("2006-01-02 15:04:05"))
	})
}

func TestCrond(t *testing.T) {
	ins, err := InitCrond()
	if err != nil {
		t.Fatalf("init crond failed:%s", err.Error())
		return
	}
	ins.DoTest(t)

	time.Sleep(20 * time.Second)
}
