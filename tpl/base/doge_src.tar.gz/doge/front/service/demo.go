package service

import (
	log "common/modules/zapkit"
	"time"
)

var DemoSvc = new(demoSvc)

type demoSvc struct{}

// daemon示例
func (p *demoSvc) Demo() {
	for {
		log.Info("daemon demo run")
		time.Sleep(10 * time.Minute)
	}
}

// crontab示例
func (p *demoSvc) Say() {
	log.Info("crontab demo run")
}
