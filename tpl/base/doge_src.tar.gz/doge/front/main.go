package main

import (
	"common/modules/buildinfo"
	"common/modules/setting"
	log "common/modules/zapkit"
	"flag"
	"main/middleware"
	"main/routers"
	"main/service"
	"os"
	"os/signal"
	"syscall"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

var (
	confFile string
	confEnv  string
)

func initArgs() {
	flag.StringVar(&confFile, "c", "conf/app.ini", "请指定配置文件")
	flag.StringVar(&confEnv, "e", "default", "请指定运行环境")
	flag.Parse()
}

func main() {
	initArgs()

	setting.InitSetting(confFile, confEnv)

	// 初始化日志模块
	log.Init(zapkitConf())
	defer log.Sync()

	// 打印系统启动信息
	printStarting()

	//监听程序退出事件
	subscribeSignal()

	r := gin.New()
	routers.Register(r)

	// 初始化中间件
	middleware.InitMiddleware(r)

	// 初始化service模块
	service.InitService()

	r.Run(":" + setting.Config.MustString("", "8080"))
}

// 定义close方法
func close() {
	log.Info("start cleaning")
	service.CloseService()
}

// 获取zapkit日志配置
func zapkitConf() *log.ZapkitConfig {
	zapkitConfig := log.ZapkitConfig{
		File:       setting.Config.MustString("zapkit.file", "/tmp/zapkit.log"),
		Level:      setting.Config.MustString("zapkit.level", "info"),
		MaxSize:    setting.Config.MustInt("zapkit.maxsize", 512),
		MaxBackups: setting.Config.MustInt("zapkit.maxbackups", 10),
		MaxAge:     setting.Config.MustInt("zapkit.age", 7),
		Compress:   setting.Config.MustBool("zapkit.compress", false),
	}
	return &zapkitConfig
}

// 打印启动日志
func printStarting() {
	log.Info(setting.Config.MustString("app.name", ""), zap.String("env", setting.AppEnv),
		zap.String("version", setting.Config.MustString("app.version", "")),
		zap.String("loglevel", setting.Config.MustString("zapkit.level", "info")),
		zap.String("buildTime", buildinfo.GetBuildTime()),
		zap.String("buildGoVersion", buildinfo.GetBuildGoVersion()))
}

// 监听退出事件
func subscribeSignal() {
	c := make(chan os.Signal)
	signal.Notify(c, syscall.SIGHUP, syscall.SIGINT, syscall.SIGTERM, syscall.SIGQUIT, syscall.SIGUSR1, syscall.SIGUSR2)
	go func() {
		for s := range c {
			switch s {
			case syscall.SIGHUP, syscall.SIGINT, syscall.SIGTERM, syscall.SIGQUIT:
				close()
			default:
			}
		}
	}()
}
