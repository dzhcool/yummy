package middleware

import (
	"main/controller/base"
	// "main/model"

	"github.com/gin-gonic/gin"
)

func InitMiddleware(r *gin.Engine) {
	r.MaxMultipartMemory = 60 * 1024 * 1024
	r.Use(gin.Recovery())

	// 初始化控制器中方法
	base.InitCtls()
	// 初始化model
	// model.InitDB()
}
