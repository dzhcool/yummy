package middleware

import (
	"common/utils"
	"fmt"
	"html/template"
	"math"
	"net/url"

	"github.com/gin-gonic/gin"
)

func PagerV4(c *gin.Context, total int, args ...int) template.HTML {
	page := utils.MustInt(c.Query("page"))
	if page <= 0 {
		page = 1
	}

	pagesize := utils.MustInt(c.Query("pagesize"))
	if pagesize <= 0 || pagesize > 5000 {
		pagesize = 15
	}
	if len(args) > 0 {
		if args[0] > 0 {
			pagesize = args[0]
		}
	}

	totalPage := int(math.Ceil(float64(total) / float64(pagesize)))
	if page >= totalPage {
		page = totalPage
	}

	uper := math.Max(1, float64(page-1))
	downer := math.Min(float64(totalPage), float64(page+1))

	return renderPageV4Html(c, page, totalPage, total, int(uper), int(downer))
}

func renderPageV4Html(c *gin.Context, page, totalPage, total, uper, downer int) template.HTML {
	code := `<nav aria-label="Page navigation pagev4">`
	code += `<ul class="pagination">`
	if uper < page {
		code += fmt.Sprintf(`<li class="page-item"><a class="page-link" href="%s" aria-label="Previous"><span aria-hidden="true">&laquo;</span></a></li>`, htmlPageUrl(c, uper))
	} else {
		code += `<li class="page-item disabled"><a class="page-link" href="#" tabindex="-1" aria-disabled="true"><span aria-hidden="true">&laquo;</span></a></li>`
	}
	if page > 1 {
		for i := 5; i > 0; i-- {
			offset := page - i
			if offset >= 1 && offset != page {
				code += fmt.Sprintf(`<li class="page-item"><a class="page-link" href="%s">%d</a></li>`, htmlPageUrl(c, offset), offset)
			}
		}
	}
	code += fmt.Sprintf(`<li class="page-item active" aria-current="page"><a class="page-link" href="%s">%d</a></li>`, htmlPageUrl(c, page), page)
	if page < totalPage {
		for i := 1; i < 5; i++ {
			offset := page + i
			if offset <= totalPage && offset != page {
				code += fmt.Sprintf(`<li class="page-item"><a class="page-link" href="%s">%d</a></li>`, htmlPageUrl(c, offset), offset)
			}
		}
	}
	if downer > page {
		code += fmt.Sprintf(`<li class="page-item"><a class="page-link" href="%s" aria-label="Next"><span aria-hidden="true">&raquo;</span></a></li>`, htmlPageUrl(c, downer))
	} else {
		code += `<li class="page-item disabled"><a class="page-link" href="#" tabindex="-1" aria-disabled="true"><span aria-hidden="true">&raquo;</span></a></li>`
	}
	code += `</ul></nav>`

	return template.HTML(code)
}

func htmlPageUrl(c *gin.Context, page int) string {
	host := c.Request.Host
	uri := c.Request.RequestURI
	u, _ := url.ParseRequestURI(uri)
	vars := u.Query()
	vars.Set("page", fmt.Sprintf("%d", page))

	newUri := ""
	id := utils.MustInt(vars.Get("id"))
	category_id := utils.MustInt(vars.Get("category_id"))
	biz := vars.Get("biz")

	switch u.Path {
	case "/product/lists":
		if category_id > 0 {
			vars.Del("category_id")
			vars.Del("page")
			if page > 1 {
				newUri = fmt.Sprintf("/product-lists-%d-page-%d.html", category_id, page)
			} else {
				newUri = fmt.Sprintf("/product-lists-%d.html", category_id)
			}
		} else {
			vars.Del("page")
			if page > 1 {
				newUri = fmt.Sprintf("/product-lists-page-%d.html", page)
			} else {
				newUri = "/product-lists.html"
			}
		}
	case "/product/view":
		if id > 0 {
			vars.Del("id")
			newUri = fmt.Sprintf("/product-view-%d.html", id)
		} else {
			newUri = "/product-view.html"
		}
	case "/page/view":
		newUri = fmt.Sprintf("/page-view-%s.html", biz)
	default:
		newUri = u.Path
	}

	exts := vars.Encode()
	address := ""
	if len(exts) <= 0 {
		address = fmt.Sprintf("//%s%s", host, newUri)
	} else {
		address = fmt.Sprintf("//%s%s?%s", host, newUri, vars.Encode())
	}
	return address
}
