package redis

import (
	"common/modules/setting"
	log "common/modules/zapkit"
	"context"

	"github.com/go-redis/redis/v8"
)

var (
	Client *redis.Client // 本地库
)

func InitRedis() error {
	host := setting.Config.MustString("redis.local.host", "127.0.0.1")
	port := setting.Config.MustString("redis.local.port", "6379")
	pwd := setting.Config.MustString("redis.local.pwd", "")

	Client = redis.NewClient(&redis.Options{
		Addr:     host + ":" + port,
		Password: pwd,
		DB:       0,
	})
	_, err := Client.Ping(context.TODO()).Result()
	if err != nil {
		log.Errorf("初始化redis失败:%s", err.Error())
		return err
	}

	return nil
}
