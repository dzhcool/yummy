package config

import (
	"common/modules/nacos"
	"common/modules/zapkit"
	"common/utils"
	"log"

	"gopkg.in/yaml.v3"
)

// nacos配置
var Config *ConfigData

const (
	GP_ONLINE = "online"
)

func InitConfig(dataId, group string) {
	confFile, err := nacos.InitConfig(dataId, group)
	if err != nil {
		log.Fatalf("初始化nacos失败，err:%s", err.Error())
		return
	}

	content, err := utils.ReadFile(confFile)
	if err != nil {
		Config = new(ConfigData)
		log.Fatalf("读取nacos配置失败，err:%s", err.Error())
		return
	}
	var cfg ConfigData
	if err = yaml.Unmarshal(content, &cfg); err != nil {
		log.Fatalf("解析nacos配置失败，err:%s", err.Error())
		return
	}
	Config = &cfg
}

func InitLocalConfig(filename string) {
	content, err := utils.ReadFile(filename)
	if err != nil {
		Config = new(ConfigData)
		log.Fatalf("读取nacos配置失败，err:%s", err.Error())
		return
	}
	var cfg ConfigData
	if err = yaml.Unmarshal(content, &cfg); err != nil {
		log.Fatalf("解析nacos配置失败，err:%s", err.Error())
		return
	}
	Config = &cfg
}

type ConfigData struct {
	App    *AppConfig           `yaml:"app"`
	Http   *HttpConfig          `yaml:"http"`
	Zapkit *zapkit.ZapkitConfig `yaml:"zapkit"`
	// Recaptcha    *RecaptchaConfig           `yaml:"recaptcha"`
	// RabbitMq     *CommonConfig              `yaml:"rabbitmq"`
	Etcd *EtcdConfig `yaml:"etcd"`
	// SiteService  *CommonConfig              `yaml:"site-service"`
	// LogService   *CommonConfig              `yaml:"log-service"`
	// SrsLocalService *RedisConfig  `yaml:"srs-local-service"`
	// StatService     *CommonConfig `yaml:"stat-service"`
	// NginxService    *CommonConfig `yaml:"nginx-service"`
	Redis          *RedisConfig `yaml:"redis"`
	RedisNodeSlave *RedisConfig `yaml:"redis-node-slave"`
	// RedisLocal      *RedisConfig `yaml:"redis-local"`
	// RedisSlaveof map[string]*RedisSlaveConf `yaml:"redis-slaveof"`
}

type AppConfig struct {
	Name       string `yaml:"name"`       // 项目名称
	Env        string `yaml:"env"`        // 运行环境
	Version    string `yaml:"version"`    // 验证配置文件更新,非程序版本号
	Autoconfig string `yaml:"autoconfig"` // autoconfig目录
}

type HttpConfig struct {
	Port int    `yaml:"port"` // 监听http端口
	Sign string `yaml:"sign"`
}

type ZapkitConfig struct {
	File       string `yaml:"file"`
	Level      string `yaml:"level"`
	MaxSize    int    `yaml:"maxsize"`
	MaxBackups int    `yaml:"maxbackups"`
	MaxAge     int    `yaml:"maxage"`
	Compress   bool   `yaml:"compress"`
}

type RecaptchaConfig struct {
	Secret string `yaml:"secret"`
}

// 通用配置， url user passwd timeout
type CommonConfig struct {
	Url     string `yaml:"url"`
	User    string `yaml:"user"`
	Passwd  string `yaml:"passwd"`
	Timeout int    `yaml:"timeout"`
}

type EtcdConfig struct {
	Url      string `yaml:"url"`
	Username string `yaml:"username"`
	Password string `yaml:"password"`
	Timeout  int    `yaml:"timeout"`
}

type RedisConfig struct {
	Host   string `yaml:"host"`
	Port   int    `yaml:"port"`
	Passwd string `yaml:"passwd"`
}

type RedisSlaveConf struct {
	MasterIp   string `json:"master_ip" yaml:"master_ip"`
	MasterPort int    `json:"master_port" yaml:"master_port"`
	MasterAuth string `json:"master_auth" yaml:"master_auth"`
}
