package rabbitmq

import (
	log "common/modules/zapkit"
	"testing"
)

func init() {
	log.ThirdInit("/tmp/test.log", "debug")
}

func Test_consumer(t *testing.T) {
	consumer, err := NewConsumer("amqp://admin:Nosmoking3311@v3-stg0.greycdn.com:5672/")
	if err != nil {
		t.Fatalf("connect rabbitmq err:%s", err.Error())
		return
	}
	consumer.Consumer("area-fanout-exchange", "fanout", "area-server", "", "", consumer_handle)
}

func Test_consumer2(t *testing.T) {
	consumer, err := NewConsumer("amqp://admin:Nosmoking3311@v3-stg0.greycdn.com:5672/")
	if err != nil {
		t.Fatalf("connect rabbitmq err:%s", err.Error())
		return
	}
	consumer.Consumer("node-exchange", "direct", "node-service-queue", "node-service-queue", "", consumer_handle)
}

// 消费函数
func consumer_handle(messageId string, deliveryTag uint64, body []byte) error {
	log.Infof("收到消息：%s", string(body))
	return nil
}
