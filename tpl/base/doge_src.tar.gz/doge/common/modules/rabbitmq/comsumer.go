package rabbitmq

import (
	log "common/modules/zapkit"

	"github.com/streadway/amqp"
)

type Consumer struct {
	url     string
	conn    *amqp.Connection
	channel *amqp.Channel
}

// 初始化
func NewConsumer(url string) (*Consumer, error) {
	consumer := &Consumer{
		url: url,
	}
	if err := consumer.newConn(); err != nil {
		log.Errorf("创建RabbitMQ连接失败: %s url: %s", err.Error(), url)
		return nil, err
	}
	return consumer, nil
}

// 创建连接
func (p *Consumer) newConn() error {
	conn, err := amqp.Dial(p.url)
	if err != nil {
		return err
	}
	ch, err := conn.Channel()
	if err != nil {
		return err
	}

	p.conn = conn
	p.channel = ch
	return nil
}

// 消费
func (p *Consumer) Consumer(exchange, exchangeType, queueName, key, tag string, handle func(string, uint64, []byte) error) error {
	if p.channel == nil {
		p.newConn()
	}
	if err := p.channel.ExchangeDeclare(
		exchange,
		exchangeType,
		true,  // durable
		false, // delete when complete
		false, // internal
		false, // noWait
		nil,   // arguments
	); err != nil {
		return err
	}

	var queue amqp.Queue
	var err error

	if queue, err = p.channel.QueueDeclarePassive(queueName, true, false, false, false, nil); err != nil { // 检查是否创建过
		if queue, err = p.channel.QueueDeclare(
			queueName,
			true,  // durable
			false, // delete when unused
			false, // exclusive
			false, // noWait
			nil,   // arguments
		); err != nil {
			return err
		}
	}

	if err := p.channel.QueueBind(
		queue.Name,
		key, // bindingKey
		exchange,
		false, // noWait
		nil,   // arguments
	); err != nil {
		return err
	}

	deliveries, err := p.channel.Consume(
		queue.Name,
		tag,
		false, // noAck
		false, // exclusive
		false, // noLocal
		false, // noWait
		nil,   // arguments
	)
	if err != nil {
		return err
	}

	for d := range deliveries {
		if err := handle(d.MessageId, d.DeliveryTag, d.Body); err != nil {
			log.Errorf("RabbitMQ consumer err: %s msg: %s", err.Error(), string(d.Body))
			continue
		}
		// 确认消息，必须传递false
		if err := d.Ack(false); err != nil {
			log.Errorf("RabbitMQ ack err: %s msg: %s", err.Error(), string(d.Body))
		}
	}

	return nil
}

// 关闭
func (p *Consumer) Close() error {
	if err := p.channel.Close(); err != nil {
		return err
	}
	if err := p.conn.Close(); err != nil {
		return err
	}
	return nil
}
