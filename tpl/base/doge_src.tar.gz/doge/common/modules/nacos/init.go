package nacos

// @date 2021-08-18 11:21

import (
	"common/modules/errors"
	"common/utils"
	"fmt"
	"log"
	"os"
	"strings"

	"github.com/nacos-group/nacos-sdk-go/clients"
	"github.com/nacos-group/nacos-sdk-go/clients/config_client"
	"github.com/nacos-group/nacos-sdk-go/common/constant"
	"github.com/nacos-group/nacos-sdk-go/vo"
)

var (
	endpoint  string
	namespace string
	accessKey string
	secretKey string

	clientConfig constant.ClientConfig
	configClient config_client.IConfigClient
)

func InitConfig(dataId, group string) (string, error) {
	endpoint = utils.Getenv("GP_NACOS_ENDPOINT", "")
	namespace = utils.Getenv("GP_NACOS_NAMESPACE", "")
	accessKey = utils.Getenv("GP_NACOS_ACCESSKEY", "")
	secretKey = utils.Getenv("GP_NACOS_SECRETKEY", "")

	workPath := os.Getenv("GP_WORK_PATH")
	if workPath != "" {
		workPath = strings.TrimRight(workPath, "/") + "/"
	}
	confFile := workPath + "conf/" + dataId

	fmt.Printf("[nacos env] endpoint:%s namespace:%s accessKey:%s, secretKey:%s confFile:%s \n",
		endpoint, namespace, accessKey, secretKey, confFile)

	endpoint = strings.ToLower(strings.TrimSuffix(endpoint, "/"))
	if !strings.HasPrefix(endpoint, "http://") && !strings.HasPrefix(endpoint, "https://") {
		endpoint = "http://" + endpoint
	}
	api := fmt.Sprintf("%s/nacos/v1/cs/configs?tenant=%s&dataId=%s&group=%s", endpoint, namespace, dataId, group)

	var err error
	for retry := 0; retry < 3; retry++ {
		if _, err = utils.HTTPDownload(api, confFile); err != nil {
			if err != nil {
				continue
			}
			break
		}
	}
	return confFile, err
}

func initConfig(dataId, group string) {

	clientConfig = constant.ClientConfig{
		Endpoint:       endpoint,
		NamespaceId:    namespace,
		AccessKey:      accessKey,
		SecretKey:      secretKey,
		TimeoutMs:      5 * 1000,
		ListenInterval: 30 * 1000 * 60,
	}

	var err error
	configClient, err = clients.CreateConfigClient(map[string]interface{}{
		"clientConfig": clientConfig,
	})
	if err != nil {
		log.Fatalf("创建nacos客户端失败,err:%s", err.Error())
		return
	}

	if err = getConfig(dataId, group); err != nil {
		log.Fatalf("获取nacos配置失败，err:%s", err.Error())
		return
	}
}

func getConfig(dataId, group string) error {
	if configClient == nil {
		return errors.New("nacos客户端不可用")
	}
	content, err := configClient.GetConfig(vo.ConfigParam{
		DataId: dataId,
		Group:  group,
	})
	if err != nil {
		return err
	}
	if _, err = utils.WriteFile(dataId+".yml", []byte(content)); err != nil {
		return err
	}
	return nil
}

// https://help.aliyun.com/document_detail/130146.html
func init() {
	// endpoint = utils.Getenv("GP_NACOS_ENDPOINT", "")
	// namespace = utils.Getenv("GP_NACOS_NAMESPACE", "")
	// accessKey = utils.Getenv("GP_NACOS_ACCESSKEY", "")
	// secretKey = utils.Getenv("GP_NACOS_SECRETKEY", "")
	// fmt.Printf("[nacos env] endpoint:%s namespace:%s accessKey:%s, secretKey:%s \n",
	// 	endpoint, namespace, accessKey, secretKey)
}
