package sendmail

import (
	"testing"
)

func Test_run(t *testing.T) {
	host := "smtp.mxhichina.com"
	port := 587
	user := "dangzihao@unique-technology.com"
	passwd := "dang2009XH*"

	client := NewGMail(host, port, user, passwd)

	err := client.Mail(user, []string{"dzhcool@qq.com"}, nil, "测试发送", "这事邮件内容<h1></h1>", ContentTypeHtml)
	if err != nil {
		t.Fatalf("发送邮件失败：%s", err.Error())
	}
}
