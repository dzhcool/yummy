package utils

import (
	"testing"
)

func Test_StrDecode(t *testing.T) {
	str := `"{\"content\":\"SHELL=/bin/bash\\nPATH=/sbin:/bin:/usr/sbin:/usr/bin\\nMAILTO=root\\n\\n# For details see man 4 crontabs\\n\\n# Example of job definition:\\n# .---------------- minute (0 - 59)\\n# |  .------------- hour (0 - 23)\\n# |  |  .---------- day of month (1 - 31)\\n# |  |  |  .------- month (1 - 12) OR jan,feb,mar,apr ...\\n# |  |  |  |  .---- day of week (0 - 6) (Sunday=0 or 7) OR sun,mon,tue,wed,thu,fri,sat\\n# |  ||  |  |\\n# *  *  *  *  * user-name  command to be executed\\n\\n*/1 * * * * root date '+\\\\%F \\\\%H:\\\\%M' \u003e\u003e/root/stat.log; /usr/bin/python /greycdn/tool/stat.py\\n0 */1 * * *  root sleep 1;/bin/bash /greycdn/tool/reload.sh\\n*/2 * * * * root sleep 2;/bin/bash /greycdn/tool/empty_biglog.sh\\n*/1 * * * * root sleep 5;/bin/bash /greycdn/tool/check.sh\\n30 3 * * * root /bin/bash /greycdn/tool/synctime.sh\\n0 6 * * *root find /greycdn/tool/logs/ -mtime +2 -name \\\"*.log*\\\" -delete\",\"modifyBy\":\"1\",\"modifyDate\":1606964042999,\"name\":\"crontab\"}"`

	data := StrDecode(str)

	t.Log(data)
}
