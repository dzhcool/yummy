package utils

import (
	"strings"

	"github.com/pquerna/ffjson/ffjson"
)

// fix json
func StrDecode(js string) string {
	if len(js) <= 0 {
		return ""
	}
	str := strings.Replace(js, `\"`, `"`, -1)
	str = strings.TrimPrefix(str, `"`)
	str = strings.TrimSuffix(str, `"`)
	return str
}

func FixJsonDecode(js string, buf interface{}) (string, error) {
	str := StrDecode(js)
	if err := ffjson.Unmarshal([]byte(str), buf); err != nil {
		return str, err
	}
	return str, nil
}

func JsonDecode(str string, buf interface{}) (string, error) {
	if err := ffjson.Unmarshal([]byte(str), buf); err != nil {
		return str, err
	}
	return str, nil
}
