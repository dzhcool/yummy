package main

const genCodecPath = "github.com/ugorji/go/codec"
